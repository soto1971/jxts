# JexBotv4
Auto Scanner and Auto exploiter web app tool V4 Leaked by #GhostSec


Required PIP MODULE: https://pypi.org/project/weblib/ use pip install weblib 

Happy Hacking 

https://t.me/GhostSecc
Twitter: @SebastianDalex
